package com.ps.greenfleet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreenfleetApplicationTests {

	@Test
	void contextLoads() {
	}

}
