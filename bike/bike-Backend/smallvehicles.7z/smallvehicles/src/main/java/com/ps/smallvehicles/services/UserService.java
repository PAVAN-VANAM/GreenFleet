package com.ps.smallvehicles.services;

import com.ps.smallvehicles.Entities.User;
import com.ps.smallvehicles.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User createUser(User user) {
        return userRepository.save(user);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> loginUser(String email, String password) {
        return userRepository.findByEmail(email)
                .filter(user -> user.getPassword().equals(password));
    }

    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    public User updateUser(Long id, User userDetails) {
        return userRepository.findById(id)
                .map(user -> {
                    user.setName(userDetails.getName());
                    user.setEmail(userDetails.getEmail());
                    user.setPassword(userDetails.getPassword());
                    user.setRating(userDetails.getRating());
                    user.setStateOfRidePool(userDetails.getStateOfRidePool());
                    user.setBikeNumber(userDetails.getBikeNumber());
                    user.setBikeLicense(userDetails.getBikeLicense());
                    user.setCo2Rate(userDetails.getCo2Rate());
                    user.setPucCertificate(userDetails.getPucCertificate());
                    return userRepository.save(user);
                })
                .orElseThrow(() -> new RuntimeException("User not found with id " + id));
    }

    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
}
